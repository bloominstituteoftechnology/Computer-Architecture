from flask import Flask, Blueprint, jsonify, redirect, render_template

from app.models import db, Record, New_York, parse_records
import openaq

root_routes = Blueprint("root_routes", __name__)

api = openaq.OpenAQ()
status, body = api.measurements(city='Los Angeles', parameter='pm25')
# print(status)
# print(body)
# print(len(body["results"]))

# los_angeles = api.measurements(city='Los Angeles', parameter='pm25')
# print(los_angeles)
data = body['results']
los_angeles_list = []
for d in data:
    los_angeles_list.append(tuple([d["date"]["utc"], d["value"]]))
# print(utc_value_list)

status2, body2 = api.measurements(name='New York', parameter='pm25')
data2 = body2['results']
# print(data2)

new_york_list = []
for d in data2:
    new_york_list.append(tuple([d["date"]["utc"], d["value"]]))
# print(new_york_list)


@root_routes.route("/")
def root():
    return render_template("qa_dashboard.html")

@root_routes.route("/los_angeles")
def los_angeles():
    records_list = Record.query.filter(Record.value >= 10).all()
    some_records = parse_records(records_list)
    return render_template("qa_los_angeles.html", records=some_records)


@root_routes.route("/new_york")
def new_york():
    ny_list = New_York.query.filter(New_York.value >= 10).all()
    ny_records = parse_records(ny_list)
    return render_template("qa_new_york.html", records=ny_records)

@root_routes.route('/los_angeles/refresh')
def refresh():
    """Pull fresh data from Open AQ and replace existing data."""
    db.drop_all()
    db.create_all()
    for rec in los_angeles_list:
        print(rec[0])
        db_record = Record(datetime=rec[0], value=rec[1])
        db.session.add(db_record)
    db.session.commit()
    print('Data refreshed!')
    return redirect("/los_angeles")


@root_routes.route('/new_york/refresh')
def refresh_ny():
    """Pull fresh data from Open AQ and replace existing data."""
    db.drop_all()
    db.create_all()
    for rec in new_york_list:
        db_record = New_York(datetime=rec[0], value=rec[1])
        db.session.add(db_record)
    db.session.commit()
    print('Data refreshed!')
    return redirect("/new_york")
